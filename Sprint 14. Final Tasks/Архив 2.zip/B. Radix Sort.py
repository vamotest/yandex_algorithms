
# https://contest.yandex.ru/contest/18970/run-report/46556816/

MAX_DIGITS = len(str(100000))


class Comparator(str):
    def get_sort_key(item):
        number = '0' * (MAX_DIGITS - len(item)) + item
        return number
    

def radix_sort(numbers):
    numbers.sort(key=Comparator.get_sort_key)
    return ' '.join(numbers)
    

if __name__ == '__main__':
    n = int(input())
    numbers_list = [str(element) for element in input().split()]
    print(radix_sort(numbers_list))
