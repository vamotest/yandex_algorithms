
# https://contest.yandex.ru/contest/18970/run-report/46491062/

class RadixSortNumbers:
    __slots__ = 'numbers'
    
    class Comparator(str):
        def get_sort_key(item):
            number = '0' * (6 - len(item)) + item
            return number
        
    def __init__(self, numbers):
        self.numbers = numbers
    
    def radix_sort(self):
        for _ in range(5, -1, -1):
            self.numbers.sort(key=self.Comparator.get_sort_key)
        return self.numbers
    

if __name__ == '__main__':
    n = int(input())
    numbers_list = [str(element) for element in input().split()]
    print(*RadixSortNumbers(numbers_list).radix_sort())
