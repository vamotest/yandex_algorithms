
# https://contest.yandex.ru/contest/18970/run-report/46430016/

class LargestNumber:
    __slots__ = 'largest_number'
    
    class Comparator(str):
        def __lt__(a, b):
            return a + b > b + a
    
    def __init__(self, numbers):
        self.largest_number = sorted(numbers, key=self.Comparator)

    def __str__(self):
        return ''.join(self.largest_number)


if __name__ == '__main__':
    n = int(input())
    numbers_list = [element for element in input().split()]
    print(LargestNumber(numbers_list))
